from django.shortcuts import render, redirect
from .forms import ContactForm
from .models import Contact

# Create your views here.
def homepage(request):
  if request.method == "POST":
    form = ContactForm(request.POST)
    if form.is_valid():
      form.save()
  contacts = Contact.objects.all()
  form = ContactForm()
  return render(request, "home.html", {"form": form, "contacts":contacts})

def view(request):
  contacts = Contact.objects.all().order_by('name', 'profession')
  return render(request, "view.html", {"contacts":contacts})

def viewname(request, name):
  contacts = Contact.objects.filter(name__contains=name)
  return render(request, "view.html", {"contacts":contacts})

def viewtel(request, tel):
  contacts = Contact.objects.filter(telephone1__contains=tel)
  return render(request, "view.html", {"contacts":contacts})

def viewprof(request, profession):
  contacts = Contact.objects.filter(profession__contains=profession)
  return render(request, "view.html", {"contacts":contacts})

def compare(request, n1, n2):
  contact1 = Contact.objects.get(name=n1)
  contact2 = Contact.objects.get(name=n2)

  if contact1.profession == contact2.profession and contact1.telephone1 == contact2.telephone1 and contact1.telephone2 == contact2.telephone2:
    return render(request, "view.html", {"contact1":contact1, "contact2":contact2, "result":"Contact 1 and 2 are the same"})
  else:
    return render(request, "view.html", {"contact1":contact1, "contact2":contact2, "result":"Contact 1 and 2 are different"})

def edit(request, name):
  contact = Contact.objects.get(name=name)
  if request.method == "POST":
    form = ContactForm(request.POST, instance=contact)
    if form.is_valid():
      form.save()
  form = ContactForm(instance=contact)
  return render(request, "edit.html", {"form": form})
 

def delete(request, name):
  contact = Contact.objects.get(name=name)
  contact.delete()
  return render(request,"mainmenu.html")




def main(request):
    return render(request, 'menu.html')
  
  
  
  

