from django.urls import path
from . import views

app_name = "main"   

urlpatterns = [

    path("", views.main, name="main"),

    path("create/", views.homepage, name="homepage"),


    path("view/", views.view, name="view"),
    path("view/<str:name>", views.viewname, name="viewname"),
    path("view/telephone1/<str:tel>", views.viewtel, name="viewtel"),
    path("view/profession/<str:profession>", views.viewprof, name="viewprof"),
    path("view/compare/<str:n1>/<str:n2>", views.compare, name="compare"),



    path("edit/<str:name>", views.edit, name="edit"),
    path("delete/<str:name>/", views.delete, name="delete"),
    
    
    
    
    


  
]